#pragma once
#include<vector>
#include<queue>
#include<fstream>
using namespace std;
class Replay
{

private:
	int x;
	int y;
	queue<pair<int, int>>replay;
public:

	void put_x_y(int x, int y);


	



};

