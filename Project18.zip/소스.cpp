#include<iostream>
#include<string>
using namespace std;
#include"MinSweeper.h"
int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	MinSweeper s;
	s.start();


	return 0;
}