#pragma once
#include<vector>
#include<iostream>
#include<queue>
#include<fstream>
using namespace std;
class mine
{




private:

	int totoal_min_num;
	vector<pair<int, int>>mines;

public:


};

